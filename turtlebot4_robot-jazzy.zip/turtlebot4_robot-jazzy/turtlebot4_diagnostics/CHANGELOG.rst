^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot4_diagnostics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.1 (2024-10-23)
------------------

2.0.0 (2024-09-25)
------------------
* Reduce the expected IMU rate to the actual rate published by the Create3
* Contributors: Chris Iverach-Brereton

1.0.3 (2024-07-02)
------------------

1.0.2 (2023-11-08)
------------------
* Merge pull request <https://github.com/turtlebot/turtlebot4_robot/issues/26>
* Remove stereo camera topic since it is not launched by default
* Update the IMU frequency
* Update rgb image topic
* Contributors: Hilary Luo

1.0.1 (2023-03-22)
------------------

1.0.0 (2023-02-21)
------------------
* Namespacing
* Minor fixes for Humble
* Contributors: Roni Kreinin

0.1.3 (2022-09-15)
------------------

0.1.2 (2022-05-30)
------------------

0.1.1 (2022-05-24)
------------------

0.1.0 (2022-05-24)
------------------
* First Galactic release
* Contributors: Roni Kreinin
